let invoiceItems = [];

function addItem() {
    const code = document.getElementById('item-code').value;
    if (!code) return;

    fetch(`fetch-item.php?code=${code}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }

            const existing = invoiceItems.find(i => i.item_code === data.item_code);
            if (existing) {
                existing.qty += 1;
            } else {
                invoiceItems.push({ ...data, qty: 1 });
            }

            renderInvoice();
            document.getElementById('item-code').value = '';
        });
}

function renderInvoice() {
    const tbody = document.querySelector('#invoice-table tbody');
    tbody.innerHTML = '';

    let grandTotal = 0;

    invoiceItems.forEach((item, index) => {
        const total = item.qty * item.price;
        grandTotal += total;

        const row = `
            <tr>
                <td>${item.item_code}</td>
                <td>${item.name}</td>
                <td>${item.price}</td>
                <td><input type="number" value="${item.qty}" onchange="updateQty(${index}, this.value)"></td>
                <td>${total.toFixed(2)}</td>
                <td><button onclick="removeItem(${index})">Remove</button></td>
            </tr>
        `;
        tbody.innerHTML += row;
    });

    document.getElementById('grand-total').innerText = grandTotal.toFixed(2);
}

function updateQty(index, value) {
    invoiceItems[index].qty = parseInt(value);
    renderInvoice();
}

function removeItem(index) {
    invoiceItems.splice(index, 1);
    renderInvoice();
}

function submitInvoice() {
    alert("Invoice submitted. (You can connect this with a backend to save invoice details.)");
}

function submitInvoice() {
    const payload = {
        name: document.getElementById('customer-name').value,
        address: document.getElementById('customer-address').value,
        phone: document.getElementById('phone-search').value,
        total: parseFloat(document.getElementById('grand-total').innerText),
        items: invoiceItems.map(item => ({
            item_code: item.item_code,
            name: item.name,
            price: item.price,
            qty: item.qty,
            total: item.qty * item.price
        }))
    };

    fetch('submit-invoice.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.invoice_number) {
            window.open(`print-invoice.php?invoice=${data.invoice_number}`, '_blank');
        }
    });
}
